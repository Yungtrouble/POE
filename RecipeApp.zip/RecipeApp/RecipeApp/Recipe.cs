﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace RecipeApp
{
    public class Recipe : INotifyPropertyChanged
    {
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Name)));
            }
        }

        public List<Ingredient> Ingredients { get; set; }

        private int totalCalories;
        public int TotalCalories
        {
            get { return totalCalories; }
            set
            {
                totalCalories = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TotalCalories)));
            }
        }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public int CalculateTotalCalories()
        {
            return Ingredients.Sum(i => i.Calories);
        }
    }
}
