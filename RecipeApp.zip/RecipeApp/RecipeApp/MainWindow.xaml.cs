﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeApp
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private ObservableCollection<Recipe> recipes;
        private ObservableCollection<Recipe> filteredRecipes;
        private string filterText;

        public event PropertyChangedEventHandler PropertyChanged;

        public ObservableCollection<Recipe> Recipes
        {
            get { return recipes; }
            set
            {
                recipes = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Recipes)));
                FilterRecipes();
            }
        }

        public ObservableCollection<Recipe> FilteredRecipes
        {
            get { return filteredRecipes; }
            set
            {
                filteredRecipes = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FilteredRecipes)));
            }
        }

        public string FilterText
        {
            get { return filterText; }
            set
            {
                filterText = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FilterText)));
                FilterRecipes();
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            Recipes = new ObservableCollection<Recipe>();
            FilteredRecipes = new ObservableCollection<Recipe>();
            DataContext = this;
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListView.SelectedItem is Recipe selectedRecipe)
            {
                if (!string.IsNullOrWhiteSpace(IngredientNameTextBox.Text) &&
                    int.TryParse(CaloriesTextBox.Text, out int calories) &&
                    FoodGroupComboBox.SelectedItem is ComboBoxItem foodGroupItem)
                {
                    var ingredient = new Ingredient
                    {
                        Name = IngredientNameTextBox.Text,
                        Calories = calories,
                        FoodGroup = foodGroupItem.Content.ToString()
                    };

                    selectedRecipe.Ingredients.Add(ingredient);
                    selectedRecipe.TotalCalories = selectedRecipe.CalculateTotalCalories();
                    ClearIngredientFields();
                }
                else
                {
                    MessageBox.Show("Please enter valid ingredient details.");
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe to add ingredients to.");
            }
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(RecipeNameTextBox.Text))
            {
                var recipe = new Recipe { Name = RecipeNameTextBox.Text };
                Recipes.Add(recipe);
                FilterRecipes();
                RecipesListView.SelectedItem = recipe;
                ClearRecipeFields();
            }
            else
            {
                MessageBox.Show("Please enter a recipe name.");
            }
        }

        private void ClearRecipeFields()
        {
            RecipeNameTextBox.Text = "";
        }

        private void ClearIngredientFields()
        {
            IngredientNameTextBox.Text = "";
            CaloriesTextBox.Text = "";
            FoodGroupComboBox.SelectedIndex = -1;
        }

        private void FilterTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            FilterText = FilterTextBox.Text;
        }

        private void FilterRecipes()
        {
            if (string.IsNullOrWhiteSpace(FilterText))
            {
                FilteredRecipes = new ObservableCollection<Recipe>(Recipes);
            }
            else
            {
                FilteredRecipes = new ObservableCollection<Recipe>(Recipes.Where(r => r.Name.Contains(FilterText, System.StringComparison.OrdinalIgnoreCase)));
            }
        }

        private void RecipesListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (RecipesListView.SelectedItem is Recipe selectedRecipe)
            {
                SelectedRecipeDetails.Text = $"Recipe: {selectedRecipe.Name}\nTotal Calories: {selectedRecipe.TotalCalories}\nIngredients:\n" +
                                             string.Join("\n", selectedRecipe.Ingredients.Select(i => $"{i.Name} - {i.Calories} Calories - {i.FoodGroup}"));
            }
        }
    }
}
